package jp.ac.databaesesample01;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class MyDatabaseHelper extends SQLiteOpenHelper {
    //DB名の定義
    private  final static String DB_NAME = "MyDatabaseSample";

    //バージョンの定義
    private final static int DB_VERSION = 1;
    public MyDatabaseHelper(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        //テーブルの作成
        sqLiteDatabase.execSQL("create table localsp(_id integer primary key autoincrement, pfname text not null, spname text not null, price integer, others text)");

        //サンプルデータの格納
        ContentValues contentValues = new ContentValues();

        //DBのフィールド名をkey、値をvalueとして格納する
        contentValues.put("pfname","福岡");
        contentValues.put("spname","あまおう");
        contentValues.put("price",900);
        contentValues.put("others","甘いです。");

        //テーブルに挿入
        sqLiteDatabase.insert("localsp",null,contentValues);

        //contentValuesのクリア
        contentValues.clear();


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
