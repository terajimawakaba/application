package jp.ac.databaesesample01;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //DB接続の準備
        MyDatabaseHelper helper = new MyDatabaseHelper(this);

        //DB(テーブル)操作の準備
        SQLiteDatabase db = helper.getWritableDatabase();

        //queryの発行準備
        //取得したいフィールドを配列で準備
        //フィールド名で配列を作る
        //今回は全フィールドを取得してみる
        //配列名をcolとして作成
        String[] col = {"_id","pfname","spname","price","others"};

        //query(sql)
        Cursor cursor = db.query("localsp",col,null,null,null,null,null);

        //カーソルを先頭に移動
        cursor.moveToFirst();

        //データの取得(特産品名を取得)
        String spName = cursor.getString(2);

        //TextViewに表示する
        TextView tv = findViewById(R.id.textView);
        tv.setText(spName);

    }
}